import javax.swing.*;
public class EnigmaGUI {

    public static void main(String args[]) {
        EnigmaFrame ef = new EnigmaFrame();
        ef.setVisible(true);
    }
    
}